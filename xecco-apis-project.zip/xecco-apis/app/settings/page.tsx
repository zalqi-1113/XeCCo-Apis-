"use client";

import { themes, usePreferences, type Theme, type TextStyle } from "@/store/usePreferences";
import { useKeyStore } from "@/store/useKeyStore";

const descriptions: Record<Theme, string> = {
  milk: "White / monochrome", night: "Dark blue accent", sky: "Light cyan", "deep-void": "Pure black",
  "luxury-gold": "Black and gold", violence: "Dark red", desert: "Warm sand", forest: "Deep green"
};

export default function SettingsPage() {
  const theme = usePreferences((s) => s.theme);
  const setTheme = usePreferences((s) => s.setTheme);
  const textStyle = usePreferences((s) => s.textStyle);
  const setTextStyle = usePreferences((s) => s.setTextStyle);
  const apiKey = useKeyStore((s) => s.apiKey);
  const clearKey = useKeyStore((s) => s.clearKey);
  const styles: { id: TextStyle; label: string; description: string }[] = [
    { id: "normal", label: "Normal", description: "Standard interface text" },
    { id: "numbers", label: "1️⃣2️⃣3️⃣", description: "Convert numbers to keycap emoji" },
    { id: "emoji", label: "Emoji", description: "Add thematic AI emoji to labels" },
    { id: "latin", label: "Latin", description: "Decorative serif-style mode" },
    { id: "binary", label: "Binary code", description: "Convert text to binary representation" }
  ];

  return <main className="shell py-10"><div className="max-w-3xl"><p className="text-xs font-bold tracking-[.2em]" style={{ color: "var(--accent)" }}>PREFERENCES</p><h1 className="mt-2 text-3xl font-black">Settings</h1><p className="mt-2 muted">Preferensi tersimpan di browser ini.</p>
    <section className="panel mt-6 p-5 sm:p-7"><h2 className="text-xl font-bold">Global theme</h2><p className="mt-1 text-sm muted">Pilih salah satu dari delapan preset.</p><div className="mt-4 grid gap-3 sm:grid-cols-2">{themes.map((item) => <button key={item} onClick={() => setTheme(item)} className="panel-soft flex items-center gap-3 p-4 text-left" style={{ outline: theme === item ? "2px solid var(--accent)" : "none" }}><span className="h-9 w-9 rounded-full border" style={{ background: item === "milk" ? "#fff" : item === "sky" ? "#0284c7" : item === "luxury-gold" ? "#d4af37" : item === "violence" ? "#dc2626" : item === "forest" ? "#10b981" : item === "desert" ? "#b58900" : item === "deep-void" ? "#000" : "#3b82f6", borderColor: "var(--border)" }}/><span><strong className="block">{item}</strong><span className="text-xs muted">{descriptions[item]}</span></span><span className="ml-auto">{theme === item ? "✓" : ""}</span></button>)}</div></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">Text style</h2><div className="mt-4 grid gap-3 sm:grid-cols-2">{styles.map((item) => <button key={item.id} className="panel-soft p-4 text-left" style={{ outline: textStyle === item.id ? "2px solid var(--accent)" : "none" }} onClick={() => setTextStyle(item.id)}><strong>{item.label}</strong><p className="mt-1 text-xs muted">{item.description}</p></button>)}</div><p className="mt-3 text-xs muted">Text-style preference is stored; binary conversion is exposed as a utility for components to apply to eligible labels.</p></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">API key vault</h2><p className="mt-2 text-sm muted">Status: {apiKey ? `Key tersimpan di browser (${apiKey.slice(0, 7)}••••••••${apiKey.slice(-4)})` : "Belum ada key"}</p><button className="btn mt-4" onClick={clearKey}>Clear key from browser</button><a href="https://openrouter.ai/keys" target="_blank" rel="noreferrer" className="btn ml-2 mt-4">Manage OpenRouter keys ↗</a></section>
  </div></main>;
}
