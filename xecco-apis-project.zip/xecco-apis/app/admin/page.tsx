"use client";

import { useEffect, useState } from "react";
import { ShieldCheck, RefreshCw, Send, Save, Wrench } from "lucide-react";

type AdminData = { user: { nickname: string; email: string; role: string }; logs: { id: string; type: string; details: string; createdAt: string }[]; feedback: { id: string; nickname: string; email: string; message: string; isRead: boolean; createdAt: string }[]; maintenance: boolean; template: string; models: { id: string; name: string; provider: string; active: boolean }[] };

export default function AdminPage() {
  const [data, setData] = useState<AdminData | null>(null);
  const [error, setError] = useState("");
  const [template, setTemplate] = useState("");
  const [broadcast, setBroadcast] = useState("");
  const [status, setStatus] = useState("");

  async function load() {
    setError("");
    try {
      const response = await fetch("/api/admin/dashboard", { cache: "no-store" });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Admin access required.");
      setData(result); setTemplate(result.template ?? "");
    } catch (e) { setError(e instanceof Error ? e.message : "Gagal memuat admin."); }
  }
  useEffect(() => { void load(); }, []);

  async function action(url: string, body: unknown) {
    setStatus("");
    const response = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error ?? "Aksi gagal.");
    setStatus("Perubahan berhasil disimpan."); await load();
  }

  if (error) return <main className="shell py-12"><div className="panel max-w-xl p-7"><ShieldCheck size={30}/><h1 className="mt-3 text-2xl font-bold">Admin access</h1><p className="mt-2 muted">{error}</p><a href="/login" className="btn btn-primary mt-5">Login</a></div></main>;
  if (!data) return <main className="shell py-12"><div className="panel p-8">Memuat dashboard…</div></main>;

  return <main className="shell py-10"><div className="flex flex-wrap items-center justify-between gap-4"><div><p className="text-xs font-bold tracking-[.2em]" style={{ color: "var(--accent)" }}>OWNER CONTROL CENTER</p><h1 className="mt-2 text-3xl font-black">Admin <span style={{ color: "var(--accent)" }}>👑</span></h1><p className="mt-2 text-sm muted">Signed in as {data.user.nickname} · {data.user.email}</p></div><button className="btn" onClick={load}><RefreshCw size={16}/> Refresh</button></div>
    {status && <p className="mt-4 text-sm" role="status">{status}</p>}
    <div className="mt-6 grid gap-4 sm:grid-cols-3"><div className="panel p-5"><p className="text-sm muted">System logs</p><p className="mt-2 text-3xl font-black">{data.logs.length}</p></div><div className="panel p-5"><p className="text-sm muted">Feedback inbox</p><p className="mt-2 text-3xl font-black">{data.feedback.length}</p></div><div className="panel p-5"><p className="text-sm muted">Catalog models</p><p className="mt-2 text-3xl font-black">{data.models.length}</p></div></div>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">Maintenance mode</h2><p className="mt-1 text-sm muted">Saat aktif, API models dan halaman utama dapat menampilkan mode maintenance bagi pengguna non-owner.</p><button className="btn mt-4" onClick={() => action("/api/admin/settings", { maintenance: !data.maintenance }).catch((e) => setStatus(e.message))}><Wrench size={16}/>{data.maintenance ? "Disable maintenance" : "Enable maintenance"}</button><span className="ml-3 pill">{data.maintenance ? "ACTIVE" : "OFF"}</span></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">OTP email template</h2><textarea className="field mt-3 min-h-28" value={template} onChange={(e) => setTemplate(e.target.value)}/><p className="mt-2 text-xs muted">Variables supported: {"{{email}}"} and {"{{code}}"}.</p><button className="btn btn-primary mt-3" onClick={() => action("/api/admin/template", { template }).catch((e) => setStatus(e.message))}><Save size={16}/> Save template</button></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">Mass broadcast</h2><p className="mt-1 text-sm muted">Mengirim email ke seluruh pengguna terverifikasi. Gunakan hanya untuk pesan yang sah dan relevan.</p><textarea className="field mt-3 min-h-24" value={broadcast} onChange={(e) => setBroadcast(e.target.value)} placeholder="Isi pengumuman…"/><button className="btn btn-primary mt-3" onClick={() => { if (confirm("Kirim broadcast ke seluruh pengguna terverifikasi?")) action("/api/admin/broadcast", { message: broadcast }).then(() => setBroadcast("")).catch((e) => setStatus(e.message)); }}><Send size={16}/> Send broadcast</button></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">Model registry</h2><div className="mt-4 space-y-2">{data.models.map((model) => <div key={model.id} className="panel-soft flex flex-wrap items-center justify-between gap-3 p-3"><div><strong>{model.name}</strong><p className="text-xs muted">{model.provider} · {model.id}</p></div><button className="btn" onClick={() => action("/api/admin/models", { id: model.id, active: !model.active }).catch((e) => setStatus(e.message))}>{model.active ? "Set maintenance" : "Activate"}</button></div>)}</div></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">Recent system logs</h2><div className="mt-4 space-y-2">{data.logs.map((log) => <div key={log.id} className="panel-soft p-3"><div className="flex flex-wrap justify-between gap-2"><span className="pill">{log.type}</span><time className="text-xs muted">{new Date(log.createdAt).toLocaleString()}</time></div><p className="mt-2 break-words text-sm">{log.details}</p></div>)}</div></section>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">Feedback inbox</h2><div className="mt-4 space-y-3">{data.feedback.map((item) => <article className="panel-soft p-4" key={item.id}><div className="flex flex-wrap justify-between gap-2"><strong>{item.nickname}</strong><span className="text-xs muted">{item.email} · {new Date(item.createdAt).toLocaleString()}</span></div><p className="mt-3 whitespace-pre-wrap text-sm">{item.message}</p><button className="btn mt-3" onClick={() => action("/api/admin/feedback", { id: item.id, delete: true }).catch((e) => setStatus(e.message))}>Delete feedback</button></article>)}</div></section>
  </main>;
}
