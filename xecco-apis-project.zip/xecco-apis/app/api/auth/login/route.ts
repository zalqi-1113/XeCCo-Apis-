import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createSession } from "@/lib/security";
import { loginSchema } from "@/lib/validation";
import { jsonError, readJson } from "@/lib/http";

export async function POST(request: Request) {
  const parsed = loginSchema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Nickname atau password tidak valid.");
  const { nickname, password } = parsed.data;
  const user = await db.user.findUnique({ where: { nickname } });
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    await db.systemLog.create({ data: { type: "AUTH_FAILURE", details: `Failed login attempt for nickname ${nickname.slice(0, 24)}` } }).catch(() => undefined);
    return jsonError("Nickname atau password salah.", 401);
  }
  if (!user.isVerified) return jsonError("Email belum diverifikasi.", 403);

  await createSession({ id: user.id, email: user.email, nickname: user.nickname, role: user.role });
  return NextResponse.json({ success: true, user: { nickname: user.nickname, email: user.email, role: user.role } });
}
