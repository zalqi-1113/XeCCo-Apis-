import { NextResponse } from "next/server";
import { getSession } from "@/lib/security";

export async function GET() {
  const user = await getSession();
  return NextResponse.json({ user: user ? { nickname: user.nickname, email: user.email, role: user.role } : null });
}
