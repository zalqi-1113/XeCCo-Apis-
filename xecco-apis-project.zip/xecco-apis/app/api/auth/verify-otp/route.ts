import { NextResponse } from "next/server";
import { verifyOtp } from "@/lib/otp";
import { verifySchema } from "@/lib/validation";
import { jsonError, readJson } from "@/lib/http";

export async function POST(request: Request) {
  const parsed = verifySchema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Email atau kode harus valid; kode terdiri dari 8 karakter.");
  const result = await verifyOtp(parsed.data.email, parsed.data.code);
  if (!result.ok) return jsonError(result.reason, 400);
  return NextResponse.json({ success: true, message: "Email berhasil diverifikasi." });
}
