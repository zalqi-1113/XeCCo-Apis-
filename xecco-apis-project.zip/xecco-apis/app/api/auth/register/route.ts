import bcrypt from "bcryptjs";
import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateOtp, storeOtp } from "@/lib/otp";
import { sendBirdEmail } from "@/lib/bird";
import { registerSchema } from "@/lib/validation";
import { jsonError, readJson } from "@/lib/http";
import { checkIsOwner } from "@/lib/owner";

export async function POST(request: Request) {
  const body = await readJson(request);
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) return jsonError("Data tidak valid. Nickname 3–24 karakter dan password minimal 10 karakter.");
  const { nickname, email, password } = parsed.data;

  const existing = await db.user.findFirst({ where: { OR: [{ email }, { nickname }] } });
  if (existing) return jsonError(existing.email === email ? "Email sudah terdaftar." : "Nickname sudah digunakan.", 409);

  const passwordHash = await bcrypt.hash(password, 12);
  const role = checkIsOwner(nickname, email) ? "OWNER" : "DEVELOPER";
  await db.user.create({ data: { nickname, email, passwordHash, role, isVerified: false } });
  const code = generateOtp();
  await storeOtp(email, code);

  try {
    const saved = await db.otpTemplate.findUnique({ where: { id: "default" } });
    const template = saved?.template ?? "Halo {{email}}, kode XeCCo kamu: {{code}}";
    await sendBirdEmail({
      to: email,
      subject: "Verifikasi akun XeCCo APIs",
      body: template.replaceAll("{{email}}", email).replaceAll("{{code}}", code)
    });
  } catch (error) {
    // Keep the account unverified and never expose the OTP in the API response.
    await db.systemLog.create({ data: { type: "API_ERROR", details: `OTP email dispatch failed: ${error instanceof Error ? error.message : "unknown error"}` } });
    return jsonError("Akun dibuat tetapi email OTP gagal dikirim. Admin perlu memeriksa konfigurasi email.", 503);
  }

  return NextResponse.json({ success: true, message: "Kode verifikasi dikirim ke email." }, { status: 201 });
}
