import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOwner } from "@/lib/security";
import { jsonError, readJson } from "@/lib/http";

const schema = z.object({ id: z.string().min(1), delete: z.literal(true) });

export async function POST(request: Request) {
  if (!(await requireOwner())) return jsonError("Akses admin ditolak.", 403);
  const parsed = schema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Payload tidak valid.");
  await db.feedback.delete({ where: { id: parsed.data.id } }).catch(() => null);
  await db.systemLog.create({ data: { type: "ADMIN_ACTION", details: "Feedback deleted" } });
  return NextResponse.json({ success: true });
}
