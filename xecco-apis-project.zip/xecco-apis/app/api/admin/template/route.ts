import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOwner } from "@/lib/security";
import { jsonError, readJson } from "@/lib/http";

const schema = z.object({ template: z.string().min(10).max(5000) });

export async function POST(request: Request) {
  if (!(await requireOwner())) return jsonError("Akses admin ditolak.", 403);
  const parsed = schema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Template tidak valid.");
  await db.otpTemplate.upsert({
    where: { id: "default" },
    update: { template: parsed.data.template },
    create: { id: "default", template: parsed.data.template }
  });
  await db.systemLog.create({ data: { type: "ADMIN_ACTION", details: "OTP template updated" } });
  return NextResponse.json({ success: true });
}
