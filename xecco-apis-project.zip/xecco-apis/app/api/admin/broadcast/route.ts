import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOwner } from "@/lib/security";
import { jsonError, readJson } from "@/lib/http";
import { sendBirdEmail } from "@/lib/bird";

const schema = z.object({ message: z.string().trim().min(10).max(5000) });

export async function POST(request: Request) {
  const owner = await requireOwner();
  if (!owner) return jsonError("Akses admin ditolak.", 403);
  const parsed = schema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Pesan broadcast harus 10–5000 karakter.");
  if (!process.env.BIRD_API_KEY || !process.env.BIRD_EMAIL_ENDPOINT) return jsonError("Bird email belum dikonfigurasi.", 503);

  const users = await db.user.findMany({ where: { isVerified: true }, select: { email: true }, take: 5000 });
  let sent = 0;
  let failed = 0;
  // Sequential delivery avoids accidental bursts; production deployments should use a queue.
  for (const user of users) {
    try {
      await sendBirdEmail({ to: user.email, subject: "Pengumuman XeCCo APIs", body: parsed.data.message });
      sent += 1;
    } catch {
      failed += 1;
    }
  }
  await db.systemLog.create({ data: { type: "ADMIN_ACTION", details: `Broadcast complete: sent=${sent}, failed=${failed}` } });
  return NextResponse.json({ success: true, total: users.length, sent, failed });
}
