import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOwner } from "@/lib/security";
import { jsonError, readJson } from "@/lib/http";

export async function POST(request: Request) {
  if (!(await requireOwner())) return jsonError("Akses admin ditolak.", 403);
  const body = await readJson(request);
  if (!body || typeof body.maintenance !== "boolean") return jsonError("Nilai maintenance harus boolean.");
  await db.appSetting.upsert({
    where: { key: "maintenance" },
    update: { value: String(body.maintenance) },
    create: { key: "maintenance", value: String(body.maintenance) }
  });
  await db.systemLog.create({ data: { type: "ADMIN_ACTION", details: `Maintenance set to ${body.maintenance}` } });
  return NextResponse.json({ success: true });
}
