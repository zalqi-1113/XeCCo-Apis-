import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireOwner } from "@/lib/security";
import { jsonError } from "@/lib/http";

export async function GET() {
  const owner = await requireOwner();
  if (!owner) return jsonError("Akses admin ditolak.", 403);
  const [logs, feedback, setting, template, models] = await Promise.all([
    db.systemLog.findMany({ orderBy: { createdAt: "desc" }, take: 100 }),
    db.feedback.findMany({ orderBy: { createdAt: "desc" }, take: 100 }),
    db.appSetting.findUnique({ where: { key: "maintenance" } }),
    db.otpTemplate.findUnique({ where: { id: "default" } }),
    db.aIModel.findMany({ orderBy: { provider: "asc" }, select: { id: true, name: true, provider: true, active: true } })
  ]);
  return NextResponse.json({
    user: { nickname: owner.nickname, email: owner.email, role: owner.role },
    logs, feedback, maintenance: setting?.value === "true",
    template: template?.template ?? "Halo {{email}}, kode kamu: {{code}}",
    models
  });
}
