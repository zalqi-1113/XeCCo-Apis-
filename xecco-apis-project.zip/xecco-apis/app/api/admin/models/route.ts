import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireOwner } from "@/lib/security";
import { jsonError, readJson } from "@/lib/http";

const schema = z.object({ id: z.string().min(1).max(200), active: z.boolean() });

export async function POST(request: Request) {
  if (!(await requireOwner())) return jsonError("Akses admin ditolak.", 403);
  const parsed = schema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Payload model tidak valid.");
  const result = await db.aIModel.updateMany({ where: { id: parsed.data.id }, data: { active: parsed.data.active } });
  if (!result.count) return jsonError("Model tidak ditemukan.", 404);
  await db.systemLog.create({ data: { type: "ADMIN_ACTION", details: `Model ${parsed.data.id} active=${parsed.data.active}` } });
  return NextResponse.json({ success: true });
}
