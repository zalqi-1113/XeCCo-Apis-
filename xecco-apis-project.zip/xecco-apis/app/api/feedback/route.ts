import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { feedbackSchema } from "@/lib/validation";
import { jsonError, readJson, getClientIp } from "@/lib/http";
import { getSession } from "@/lib/security";
import { sendBirdEmail } from "@/lib/bird";

export async function POST(request: Request) {
  const parsed = feedbackSchema.safeParse(await readJson(request));
  if (!parsed.success) return jsonError("Nickname, email, dan pesan wajib valid.");
  const { nickname, email, message } = parsed.data;
  const session = await getSession();
  const feedback = await db.feedback.create({
    data: { nickname, email: email.toLowerCase(), message, userId: session?.id }
  });
  await db.systemLog.create({ data: { type: "VISITOR", details: "Feedback submitted", ipAddress: getClientIp(request) } }).catch(() => undefined);

  try {
    if (process.env.OWNER_EMAIL && process.env.BIRD_API_KEY && process.env.BIRD_EMAIL_ENDPOINT) {
      await sendBirdEmail({
        to: process.env.OWNER_EMAIL,
        subject: `[XeCCo Feedback] From ${nickname}`,
        body: `User: ${nickname}\nEmail: ${email}\n\nMessage:\n${message}`
      });
    }
  } catch (error) {
    await db.systemLog.create({ data: { type: "API_ERROR", details: `Feedback email dispatch failed: ${error instanceof Error ? error.message : "unknown error"}` } }).catch(() => undefined);
  }

  return NextResponse.json({ success: true, id: feedback.id }, { status: 201 });
}
