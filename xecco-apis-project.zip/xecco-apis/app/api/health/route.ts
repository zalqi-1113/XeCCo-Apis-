import { NextResponse } from "next/server";
export async function GET() { return NextResponse.json({ status: "ok", service: "xecco-apis", timestamp: new Date().toISOString() }); }
