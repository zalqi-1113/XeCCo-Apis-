import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/security";

export async function GET() {
  const setting = await db.appSetting.findUnique({ where: { key: "maintenance" } }).catch(() => null);
  const session = await getSession();
  if (setting?.value === "true" && session?.role !== "OWNER") {
    return NextResponse.json({ success: false, maintenance: true, error: "System under maintenance." }, { status: 503 });
  }
  const models = await db.aIModel.findMany({
    where: { active: true },
    select: { id: true, name: true, provider: true, genre: true, isFree: true, contextLength: true },
    orderBy: [{ isFree: "desc" }, { provider: "asc" }, { name: "asc" }]
  });
  return NextResponse.json({ models });
}
