import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/security";
import { jsonError, readJson } from "@/lib/http";
import { profileSchema } from "@/lib/validation";
import { z } from "zod";

const imageSchema = z.string().max(1_400_000).regex(/^data:image\/(png|jpeg|webp);base64,/);

export async function GET() {
  const session = await getSession();
  if (!session) return jsonError("Silakan login terlebih dahulu.", 401);
  const user = await db.user.findUnique({
    where: { id: session.id },
    select: { id: true, email: true, nickname: true, caption: true, profilePic: true, bannerPic: true, role: true }
  });
  if (!user) return jsonError("User tidak ditemukan.", 404);
  return NextResponse.json({ user });
}

export async function PATCH(request: Request) {
  const session = await getSession();
  if (!session) return jsonError("Silakan login terlebih dahulu.", 401);
  const body = await readJson(request);
  if (!body || typeof body !== "object") return jsonError("Payload tidak valid.");
  const raw = body as Record<string, unknown>;
  const update: Record<string, unknown> = {};

  if ("nickname" in raw || "caption" in raw) {
    const parsed = profileSchema.safeParse({ nickname: raw.nickname, caption: raw.caption });
    if (!parsed.success) return jsonError("Nickname atau caption tidak valid.");
    const existing = await db.user.findFirst({ where: { nickname: parsed.data.nickname, NOT: { id: session.id } } });
    if (existing) return jsonError("Nickname sudah digunakan.", 409);
    update.nickname = parsed.data.nickname;
    update.caption = parsed.data.caption;
  }
  if ("profilePic" in raw) {
    const parsed = imageSchema.safeParse(raw.profilePic);
    if (!parsed.success) return jsonError("Foto profil harus berupa PNG, JPG, atau WebP yang valid.");
    update.profilePic = parsed.data;
  }
  if ("bannerPic" in raw) {
    const parsed = imageSchema.safeParse(raw.bannerPic);
    if (!parsed.success) return jsonError("Banner harus berupa PNG, JPG, atau WebP yang valid.");
    update.bannerPic = parsed.data;
  }
  if (!Object.keys(update).length) return jsonError("Tidak ada perubahan yang dapat disimpan.");

  const user = await db.user.update({
    where: { id: session.id },
    data: update,
    select: { id: true, email: true, nickname: true, caption: true, profilePic: true, bannerPic: true, role: true }
  });
  return NextResponse.json({ user });
}
