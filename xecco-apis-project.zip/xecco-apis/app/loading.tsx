export default function Loading() { return <main className="shell py-16"><div className="panel p-8 muted">Memuat XeCCo APIs…</div></main>; }
