import Link from "next/link";
export default function NotFound() { return <main className="shell py-24 text-center"><h1 className="text-4xl font-black">404</h1><p className="mt-3 muted">Halaman tidak ditemukan.</p><Link href="/" className="btn btn-primary mt-6">Kembali ke beranda</Link></main>; }
