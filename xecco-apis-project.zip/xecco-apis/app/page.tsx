import Link from "next/link";
import { ArrowDownRight, Shield, Zap, Layers3, Terminal } from "lucide-react";
import { ModelRegistry } from "@/components/ModelRegistry";
import { FeedbackForm } from "@/components/FeedbackForm";

export default function HomePage() {
  return <main>
    <section className="shell py-14 sm:py-20">
      <div className="grid items-center gap-10 lg:grid-cols-[1.15fr_.85fr]">
        <div>
          <span className="pill"><span className="mr-2 inline-block h-2 w-2 rounded-full" style={{ background: "var(--accent)" }}/> BYOK · Bring Your Own Key</span>
          <h1 className="mt-6 text-4xl font-black leading-[1.08] tracking-tight sm:text-6xl">Satu workspace.<br/><span style={{ color: "var(--accent)" }}>Banyak model AI.</span></h1>
          <p className="mt-5 max-w-xl text-base leading-7 muted sm:text-lg">Jelajahi katalog model, baca contoh API, dan uji prompt langsung melalui OpenRouter. Kunci API tetap berada di browser kamu—XeCCo tidak menyimpannya di server.</p>
          <div className="mt-7 flex flex-wrap gap-3"><a href="#models" className="btn btn-primary">Jelajahi model <ArrowDownRight size={17}/></a><Link href="/create" className="btn">Buat akun</Link></div>
          <div className="mt-8 flex flex-wrap gap-5 text-sm muted"><span className="flex items-center gap-2"><Shield size={16}/> BYOK-first</span><span className="flex items-center gap-2"><Zap size={16}/> Live playground</span><span className="flex items-center gap-2"><Layers3 size={16}/> Multi-provider</span></div>
        </div>
        <div className="panel relative overflow-hidden p-5 sm:p-7">
          <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full opacity-20 blur-3xl" style={{ background: "var(--accent)" }}/>
          <div className="flex items-center justify-between"><span className="text-xs tracking-[.2em] muted">XEECCO / PLAYGROUND</span><span className="pill">READY</span></div>
          <div className="mt-7 rounded-xl p-4" style={{ background: "var(--bg)", border: "1px solid var(--border)" }}>
            <div className="flex items-center gap-2 text-sm"><Terminal size={15} style={{ color: "var(--accent)" }}/> <span className="muted">POST</span> /chat/completions</div>
            <pre className="mt-4 overflow-x-auto text-xs leading-6"><code>{`{
  "model": "provider/model-id",
  "messages": [
    {
      "role": "user",
      "content": "Hello XeCCo!"
    }
  ],
  "temperature": 0.7
}`}</code></pre>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2 text-center">
            <div className="panel-soft p-3"><p className="text-xl font-bold">20</p><p className="text-xs muted">Seeded models</p></div>
            <div className="panel-soft p-3"><p className="text-xl font-bold">8</p><p className="text-xs muted">Themes</p></div>
            <div className="panel-soft p-3"><p className="text-xl font-bold">BYOK</p><p className="text-xs muted">Your key</p></div>
          </div>
        </div>
      </div>
    </section>

    <section id="models" className="shell scroll-mt-24 py-8 sm:py-12">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4"><div><p className="text-xs font-bold tracking-[.2em]" style={{ color: "var(--accent)" }}>MODEL REGISTRY</p><h2 className="mt-2 text-3xl font-black">Pilih model untuk dicoba</h2><p className="mt-2 muted">Ketersediaan model mengikuti katalog OpenRouter dan konfigurasi database kamu.</p></div><span className="pill">API docs + Playground</span></div>
      <ModelRegistry/>
    </section>

    <section className="shell grid gap-5 py-12 lg:grid-cols-2">
      <div className="panel p-6 sm:p-8"><p className="text-xs tracking-[.2em]" style={{ color: "var(--accent)" }}>WORKFLOW</p><h2 className="mt-3 text-2xl font-bold">Dibangun untuk eksperimen cepat</h2><div className="mt-5 space-y-4">{[["01","Pilih model","Filter katalog berdasarkan nama, provider, atau genre."],["02","Lihat API","Salin payload JSON untuk integrasi aplikasi."],["03","Coba prompt","Jalankan request dengan key OpenRouter milikmu."]].map(([n,title,desc])=><div className="flex gap-4" key={n}><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg text-sm font-bold" style={{ background: "var(--panel-2)", color: "var(--accent)" }}>{n}</span><div><h3 className="font-semibold">{title}</h3><p className="mt-1 text-sm muted">{desc}</p></div></div>)}</div></div>
      <FeedbackForm/>
    </section>
    <footer className="mt-8 border-t py-7" style={{ borderColor: "var(--border)" }}><div className="shell flex flex-wrap items-center justify-between gap-3 text-sm muted"><span>© {new Date().getFullYear()} XeCCo APIs</span><div className="flex gap-4"><Link href="/settings">Settings</Link><Link href="/profile">Profile</Link><Link href="/login">Login</Link></div><span>BYOK · Never share your key</span></div></footer>
  </main>;
}
