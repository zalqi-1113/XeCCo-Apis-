"use client";

import { useEffect, useState } from "react";
import { useKeyStore } from "@/store/useKeyStore";

type Profile = { id: string; email: string; nickname: string; caption: string | null; profilePic: string | null; bannerPic: string | null; role: string };

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [nickname, setNickname] = useState("");
  const [caption, setCaption] = useState("");
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);
  const [showKey, setShowKey] = useState(false);
  const [connection, setConnection] = useState("");
  const apiKey = useKeyStore((s) => s.apiKey);
  const setApiKey = useKeyStore((s) => s.setApiKey);
  const clearKey = useKeyStore((s) => s.clearKey);

  useEffect(() => {
    fetch("/api/profile").then(async (r) => {
      const data = await r.json();
      if (!r.ok) throw new Error(data.error);
      setProfile(data.user); setNickname(data.user.nickname); setCaption(data.user.caption ?? "");
    }).catch((e) => setStatus(e.message ?? "Gagal memuat profil."));
  }, []);

  async function save(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setStatus("");
    try {
      const response = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nickname, caption }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      setProfile(data.user); setStatus("Profil berhasil disimpan.");
    } catch (e) { setStatus(e instanceof Error ? e.message : "Gagal menyimpan profil."); }
    finally { setBusy(false); }
  }

  async function testKey() {
    setConnection("Memeriksa…");
    try {
      if (!apiKey) throw new Error("Masukkan API key terlebih dahulu.");
      const response = await fetch("https://openrouter.ai/api/v1/key", { headers: { Authorization: `Bearer ${apiKey}` } });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error?.message ?? `HTTP ${response.status}`);
      setConnection(`Koneksi valid. Label: ${data.data?.label ?? "OpenRouter key"}.`);
    } catch (e) { setConnection(e instanceof Error ? e.message : "Test gagal."); }
  }

  async function uploadImage(kind: "profilePic" | "bannerPic", file?: File) {
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) { setStatus("Gunakan PNG, JPG, atau WebP."); return; }
    if (file.size > 1_000_000) { setStatus("Ukuran gambar maksimal 1 MB."); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const response = await fetch("/api/profile", { method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ [kind]: reader.result }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error);
        setProfile(data.user); setStatus("Gambar profil diperbarui.");
      } catch (e) { setStatus(e instanceof Error ? e.message : "Upload gagal."); }
    };
    reader.readAsDataURL(file);
  }

  if (!profile) return <main className="shell py-12"><div className="panel p-8">{status || "Memuat profil…"}</div></main>;

  return <main className="shell max-w-4xl py-10"><p className="text-xs font-bold tracking-[.2em]" style={{ color: "var(--accent)" }}>YOUR ACCOUNT</p><h1 className="mt-2 text-3xl font-black">Profile</h1>
    <section className="panel mt-6 overflow-hidden"><div className="h-40 bg-cover bg-center" style={{ backgroundImage: profile.bannerPic ? `url(${profile.bannerPic})` : "linear-gradient(120deg,var(--panel-2),var(--accent))" }}/><div className="p-5 sm:p-7"><div className="-mt-14 flex items-end gap-4"><img src={profile.profilePic ?? "https://placehold.co/96x96/202020/FFFFFF?text=X"} alt="Profile" className="h-24 w-24 rounded-2xl border-4 object-cover" style={{ borderColor: "var(--panel)" }}/><div className="pb-1"><h2 className="text-xl font-bold">{profile.nickname} {profile.role === "OWNER" ? "👑" : ""}</h2><p className="text-sm muted">{profile.email}</p></div></div>
      <div className="mt-5 flex flex-wrap gap-3"><label className="btn">Ubah foto profil<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => uploadImage("profilePic", e.target.files?.[0])}/></label><label className="btn">Ubah banner<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => uploadImage("bannerPic", e.target.files?.[0])}/></label></div>
    </div></section>
    <form onSubmit={save} className="panel mt-5 space-y-4 p-5 sm:p-7"><h2 className="text-xl font-bold">Edit profile</h2><label className="block text-sm">Nickname<input className="field mt-2" value={nickname} onChange={(e) => setNickname(e.target.value)} required minLength={3} maxLength={24}/></label><label className="block text-sm">Caption<textarea className="field mt-2 min-h-24" value={caption} onChange={(e) => setCaption(e.target.value)} maxLength={280} placeholder="Tulis bio singkat…"/></label><button className="btn btn-primary" disabled={busy}>{busy ? "Menyimpan…" : "Simpan perubahan"}</button>{status && <p role="status" className="text-sm muted">{status}</p>}</form>
    <section className="panel mt-5 p-5 sm:p-7"><h2 className="text-xl font-bold">API Key Vault</h2><input className="field mt-3" type={showKey ? "text" : "password"} value={apiKey} onChange={(e) => setApiKey(e.target.value)} placeholder="sk-or-v1-…" autoComplete="off"/><div className="mt-3 flex flex-wrap gap-2"><button className="btn" onClick={() => setShowKey(!showKey)}>{showKey ? "Hide" : "Show"}</button><button className="btn" onClick={testKey}>Test connection</button><button className="btn" onClick={clearKey}>Clear browser key</button></div>{connection && <p className="mt-3 text-sm muted" role="status">{connection}</p>}<p className="mt-3 text-xs muted">API key tidak pernah dikirim ke endpoint XeCCo. Test connection menghubungi OpenRouter langsung dari browser.</p></section>
  </main>;
}
