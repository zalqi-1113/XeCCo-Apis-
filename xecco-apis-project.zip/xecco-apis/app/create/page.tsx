"use client";

import Link from "next/link";
import { useState } from "react";
import { useKeyStore } from "@/store/useKeyStore";

export default function CreatePage() {
  const [nickname, setNickname] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const setApiKey = useKeyStore((state) => state.setApiKey);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/auth/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ nickname, email, password }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Pendaftaran gagal.");
      const key = (document.getElementById("openrouter-key") as HTMLInputElement)?.value;
      if (key) setApiKey(key);
      window.location.href = `/verify?email=${encodeURIComponent(email)}`;
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Pendaftaran gagal."); }
    finally { setBusy(false); }
  }

  return <main className="shell flex min-h-[calc(100vh-72px)] items-center justify-center py-12"><form onSubmit={submit} className="panel w-full max-w-md space-y-4 p-6 sm:p-8"><p className="text-xs font-bold tracking-[.2em]" style={{ color: "var(--accent)" }}>CREATE ACCOUNT</p><h1 className="text-3xl font-black">Buat akun</h1><p className="text-sm muted">Password minimal 10 karakter. Verifikasi email wajib sebelum login.</p><label className="block text-sm">Nickname<input className="field mt-2" value={nickname} onChange={(e) => setNickname(e.target.value)} minLength={3} maxLength={24} required autoComplete="username"/></label><label className="block text-sm">Email<input className="field mt-2" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email"/></label><label className="block text-sm">Password<input className="field mt-2" type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={10} maxLength={128} required autoComplete="new-password"/></label><label className="block text-sm">OpenRouter API key <span className="muted">(opsional)</span><input id="openrouter-key" className="field mt-2" type="password" placeholder="sk-or-v1-…" autoComplete="off"/></label>{error && <p className="text-sm text-red-400" role="alert">{error}</p>}<button className="btn btn-primary w-full" disabled={busy}>{busy ? "Membuat akun…" : "Daftar dan verifikasi email"}</button><p className="text-center text-sm muted">Sudah terdaftar? <Link className="underline" href="/login">Masuk</Link></p></form></main>;
}
