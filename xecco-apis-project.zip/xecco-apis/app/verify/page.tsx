"use client";

import Link from "next/link";
import { useSearchParams, useRouter } from "next/navigation";
import { Suspense, useState } from "react";

function VerifyForm() {
  const params = useSearchParams();
  const router = useRouter();
  const email = params.get("email") ?? "";
  const [digits, setDigits] = useState(Array(8).fill(""));
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  function change(index: number, value: string) {
    const next = [...digits];
    next[index] = value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(-1);
    setDigits(next);
    if (next[index] && index < 7) document.getElementById(`otp-${index + 1}`)?.focus();
  }

  function keyDown(index: number, event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Backspace" && !digits[index] && index > 0) document.getElementById(`otp-${index - 1}`)?.focus();
  }

  async function submit(event: React.FormEvent) {
    event.preventDefault(); setBusy(true); setError("");
    try {
      const response = await fetch("/api/auth/verify-otp", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ email, code: digits.join("") }) });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Verifikasi gagal.");
      router.push("/login");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Verifikasi gagal."); }
    finally { setBusy(false); }
  }

  return <form onSubmit={submit} className="panel w-full max-w-md p-6 text-center sm:p-8"><p className="text-xs font-bold tracking-[.2em]" style={{ color: "var(--accent)" }}>EMAIL VERIFICATION</p><h1 className="mt-3 text-3xl font-black">Check your email!</h1><p className="mt-3 text-sm muted">Masukkan 8 karakter kode yang dikirim ke <strong>{email || "email kamu"}</strong>.</p><div className="mt-7 flex justify-center gap-2">{digits.map((digit, index) => <input key={index} id={`otp-${index}`} className="field h-12 w-10 p-0 text-center text-lg font-bold uppercase sm:h-14 sm:w-12" value={digit} onChange={(e) => change(index, e.target.value)} onKeyDown={(e) => keyDown(index, e)} maxLength={1} aria-label={`OTP character ${index + 1}`} autoComplete={index === 0 ? "one-time-code" : "off"}/>)}</div>{error && <p className="mt-4 text-sm text-red-400" role="alert">{error}</p>}<button className="btn btn-primary mt-6 w-full" disabled={busy || digits.join("").length !== 8}>{busy ? "Memverifikasi…" : "Verifikasi akun"}</button><p className="mt-4 text-xs muted">Kode berlaku 15 menit dan maksimal 5 percobaan.</p><Link href="/create" className="mt-4 inline-block text-sm underline">Kembali ke pendaftaran</Link></form>;
}

export default function VerifyPage() {
  return <main className="shell flex min-h-[calc(100vh-72px)] items-center justify-center py-12"><Suspense fallback={<div className="panel p-8">Memuat formulir…</div>}><VerifyForm/></Suspense></main>;
}
