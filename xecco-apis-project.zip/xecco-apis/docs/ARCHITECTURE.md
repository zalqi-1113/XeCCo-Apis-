# Architecture notes

## Trust boundaries

The browser is responsible for holding the user's OpenRouter API key and making model calls. The application server handles accounts, password hashes, session signing, OTP validation, profile data, feedback, model registry metadata, and admin actions. Never proxy the user API key through the XeCCo backend unless the product requirements are intentionally changed and the privacy model is revised.

## Authentication lifecycle

1. Registration validates nickname, email, and password.
2. Password is hashed using bcrypt with a cost factor of 12.
3. An eight-character random code is generated.
4. The code is hashed before storage and expires after fifteen minutes.
5. The email provider is asked to send the code.
6. The verification endpoint checks expiration and attempts, then atomically marks the user verified and deletes the OTP record.
7. Login checks password and verification state before setting an HttpOnly session cookie.

## Owner identity

The owner is recognized by a nickname and email configured on the server. The session role is recalculated from the signed identity against those environment variables. Client requests cannot set the owner role. In a production system, use a controlled owner-provisioning process and consider multi-factor authentication.

## API error shape

Most route errors use:

```json
{ "success": false, "error": "Human-readable message" }
```

Successful responses use `{ "success": true, ... }` or return the relevant resource.

## OpenRouter request

The playground sends requests to `/api/v1/chat/completions` from the browser with the Authorization bearer token. The API key is not included in any XeCCo route request. The key persists in localStorage until the user clears it.

## Known limitations

- No shared distributed rate limiter is included.
- No resend-OTP endpoint is included yet.
- Streaming output is plain text rather than a full Markdown renderer.
- Video, image generation, and rerank models are shown in the catalog, but their modality-specific workflows are not implemented in this chat playground.
- Email payload details need to be matched to the Bird account's current API documentation.
- Visitor analytics are limited to system events and do not attempt invasive tracking.
