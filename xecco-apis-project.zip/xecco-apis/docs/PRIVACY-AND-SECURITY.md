# Privacy and security notes

## OpenRouter API keys
The key is persisted in localStorage. This enables the browser-side BYOK model, but it also means browser extensions, malicious same-origin JavaScript, or someone with access to the browser profile may potentially read it. Never use this on a shared or untrusted device. Consider a session-only key option and a strict Content Security Policy.

## Passwords and sessions
Passwords are hashed using bcrypt. Session tokens are signed and stored in HttpOnly cookies with SameSite=Lax and Secure in production. Add session revocation, CSRF/origin checks, and account recovery before a public launch.

## OTP
OTP values are not stored in plaintext. Codes expire in fifteen minutes and five failed attempts lock the existing code. A distributed rate limiter is still recommended to prevent email bombing and registration abuse.

## Personal data
The database contains email, nickname, profile imagery, caption, feedback, and operational logs. Publish a privacy policy, minimize collection, define retention, and restrict database access.

## Logging
Do not write API keys, passwords, OTP codes, full authorization headers, or sensitive email contents to logs. System logs should have retention and access policies.

## Admin broadcasts
Broadcasting to all verified accounts can create provider costs and spam risk. Add a preview, recipient count confirmation, queue, suppression list, and unsubscribe handling before production.
