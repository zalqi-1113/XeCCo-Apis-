# Operations runbook

This runbook describes routine operational procedures for a self-hosted XeCCo APIs deployment. It is intentionally provider-neutral where deployment vendors differ.

## Startup sequence

1. Confirm the PostgreSQL service is reachable from the application runtime.
2. Confirm the configured database role has only the required schema privileges.
3. Confirm required environment variables exist without printing their values.
4. Run Prisma client generation during build.
5. Apply the reviewed database migration.
6. Start the application process.
7. Check `/api/health`.
8. Test model catalog loading.
9. Test an authenticated flow using a non-production account.
10. Verify that no credentials appear in application logs.

## Deployment rollback

1. Stop the release if health checks fail.
2. Preserve application logs while removing secrets and personal data.
3. Roll back to the last known-good application artifact.
4. Do not blindly roll back database migrations if they are destructive.
5. Restore from a tested backup only after confirming the incident scope.
6. Re-run health checks and a small set of read-only smoke tests.
7. Record the release identifier and the reason for rollback.

## Database backup policy

- Schedule encrypted backups according to the product's recovery-point objective.
- Keep backup credentials separate from application credentials.
- Restrict access to backups because profile images and feedback may contain personal data.
- Test restoration into an isolated environment regularly.
- Define retention periods and securely expire old backups.
- Avoid exporting production data into developer laptops or public issue trackers.

## Email delivery incidents

Symptoms can include registration returning a provider error, OTP emails not arriving, or feedback messages not reaching the owner inbox.

1. Check whether the Bird endpoint is configured.
2. Verify the sender identity and workspace permissions in Bird.
3. Review the HTTP status captured by the application, without logging the API key.
4. Confirm that the endpoint and payload match the specific Bird product enabled for the account.
5. Check delivery, bounce, suppression, and sender reputation information in Bird.
6. Do not ask users to share their OTP codes with support.
7. Do not bypass email verification by manually trusting client input.
8. After fixing configuration, use a test account and a controlled message.

## OpenRouter incidents

If playground requests fail:

1. Confirm the user's browser can reach OpenRouter.
2. Ask the user to inspect the provider error message without sharing the Authorization header.
3. Check whether the model ID is still available.
4. Confirm the key has sufficient balance or access.
5. Confirm that the chosen model supports chat completions and the requested parameters.
6. Check provider status and rate-limit responses.
7. Never ask a user to paste their full API key into a support ticket.
8. Recommend revoking and recreating a key if exposure is suspected.

## Security incident: exposed key

1. Revoke the affected key at the provider immediately.
2. Generate a replacement key only after the source of exposure is addressed.
3. Remove the key from logs, tickets, screenshots, and repositories where possible.
4. Remember that deleting a file from a repository does not remove it from commit history.
5. Review provider usage and billing for unexpected activity.
6. Rotate any other secret that was exposed in the same document or conversation.
7. Document the incident and the corrective controls.

## Account support

Support staff should not request passwords or OTP codes. For a user who cannot verify an account, investigate delivery status and registration records. A production implementation should add a rate-limited resend-code flow and a documented account-recovery process.

## Admin operations

- Review recent audit logs before and after sensitive changes.
- Preview the recipient count and content before mass broadcasts.
- Prefer a queue with bounded concurrency over synchronous mass email delivery.
- Ensure owner identity configuration is protected by the deployment platform's secret manager.
- Do not share admin screenshots containing private email addresses or feedback messages.
