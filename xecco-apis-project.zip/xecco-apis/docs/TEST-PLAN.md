# Manual acceptance test plan

## Catalog
- [ ] Home route loads on mobile and desktop.
- [ ] Search filters by model name, provider, ID, and genre.
- [ ] Genre selector and free-tier checkbox compose correctly.
- [ ] Refresh reloads the model list.
- [ ] APIs modal shows endpoint and payload without requiring a key.
- [ ] Copy payload copies valid JSON.

## Playground
- [ ] Empty key and empty prompt show validation messages.
- [ ] Valid key/model request displays response.
- [ ] Invalid key displays provider error without leaking key.
- [ ] Streaming response appends chunks as they arrive.
- [ ] Temperature and max token controls affect the request body.
- [ ] Clear key empties local persisted state.

## Account
- [ ] Invalid registration is rejected.
- [ ] Duplicate email and nickname are rejected.
- [ ] Password is never returned by APIs.
- [ ] OTP expires and invalid attempts are counted.
- [ ] Verified account can log in.
- [ ] Unverified account cannot log in.
- [ ] Logout clears session cookie.

## Profile and settings
- [ ] Profile endpoint requires authentication.
- [ ] Nickname uniqueness is enforced.
- [ ] Caption length is bounded.
- [ ] Image upload validates type and size.
- [ ] Theme persists after reload.
- [ ] API key test calls OpenRouter directly.

## Admin
- [ ] Unauthenticated requests cannot access admin APIs.
- [ ] Developer accounts cannot access admin APIs.
- [ ] Owner can read logs and feedback.
- [ ] Maintenance toggle changes model API behavior.
- [ ] OTP template update persists.
- [ ] Model active state changes in the registry.
- [ ] Broadcast reports sent/failed counts and never logs credentials.

## Feedback
- [ ] Invalid messages are rejected.
- [ ] Feedback is saved.
- [ ] Email forwarding is attempted only when provider config exists.
- [ ] Email provider failure is recorded and does not falsely report delivery.
