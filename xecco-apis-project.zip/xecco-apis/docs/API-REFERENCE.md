# Application API reference

All JSON endpoints should be called over HTTPS in production. Error responses generally use a JSON object with an `error` field.

## Authentication

### `POST /api/auth/register`

Creates an unverified account and attempts to dispatch an email verification code.

Example request:

```json
{
  "nickname": "example_user",
  "email": "user@example.com",
  "password": "a-long-password-value"
}
```

Expected outcomes:
- `201`: account created and provider dispatch accepted.
- `400`: invalid fields.
- `409`: duplicate email or nickname.
- `503`: email dispatch is not configured or failed.

A provider acceptance response does not necessarily prove inbox delivery.

### `POST /api/auth/verify-otp`

Example request:

```json
{
  "email": "user@example.com",
  "code": "GDTUZXDA"
}
```

The code is case-normalized by the client and validated on the server. Codes expire after fifteen minutes and are deleted after successful verification.

### `POST /api/auth/login`

Example request:

```json
{
  "nickname": "example_user",
  "password": "a-long-password-value"
}
```

On success, the server sets an HttpOnly session cookie. Unverified accounts cannot log in.

### `POST /api/auth/logout`

Clears the session cookie.

### `GET /api/auth/me`

Returns a minimal public identity for the active session, or `null` when logged out.

## Models

### `GET /api/models`

Returns active models, excluding internal administrative fields. If maintenance mode is enabled, non-owner requests receive HTTP `503`.

Response shape:

```json
{
  "models": [
    {
      "id": "provider/model-id",
      "name": "Example model",
      "provider": "Example provider",
      "genre": "Chat",
      "isFree": false,
      "contextLength": "32k"
    }
  ]
}
```

The sample is illustrative. The seed list must be checked against the current upstream model catalog.

## Feedback

### `POST /api/feedback`

Example request:

```json
{
  "nickname": "example_user",
  "email": "user@example.com",
  "message": "The model catalog filter is not updating."
}
```

The message is stored before optional email forwarding. Provider failure does not erase the stored feedback. The application records a generic operational error for later review.

## Profile

### `GET /api/profile`

Requires an authenticated session. Returns the user's profile fields.

### `PATCH /api/profile`

Supports nickname and caption updates, plus profile and banner images as data URLs. Images are restricted to PNG, JPEG, and WebP and bounded in size. The current implementation stores data URLs in the database; object storage is recommended for production.

## Administrative routes

Every route under `/api/admin/*` requires an owner session.

- `GET /api/admin/dashboard`: logs, feedback, template, maintenance flag, and model status.
- `POST /api/admin/settings`: changes maintenance mode.
- `POST /api/admin/template`: updates the OTP message template.
- `POST /api/admin/models`: activates or deactivates a model.
- `POST /api/admin/feedback`: deletes a feedback item.
- `POST /api/admin/broadcast`: sends a message to verified users.

Administrative actions should be audited and monitored. Broadcast delivery is synchronous in this starter and should be replaced with a durable job queue for a large user base.
