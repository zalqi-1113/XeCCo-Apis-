# Release checklist

## Product readiness
- [ ] Confirm product name, logo, and legal footer.
- [ ] Review all UI copy in Indonesian.
- [ ] Confirm mobile navigation and responsive cards.
- [ ] Check empty, loading, error, and success states.
- [ ] Validate all links and buttons.
- [ ] Review all eight themes.
- [ ] Review all five text-style preferences.
- [ ] Verify that inactive models are not displayed.
- [ ] Verify API examples match the actual upstream API.

## Data and security
- [ ] Confirm all secrets exist only in a secret manager or local environment file.
- [ ] Rotate credentials exposed in any earlier document.
- [ ] Confirm database backups are encrypted.
- [ ] Confirm owner role is not client-controlled.
- [ ] Confirm session cookies use HTTPS in production.
- [ ] Configure rate limits.
- [ ] Configure request size limits.
- [ ] Add CSRF/origin validation.
- [ ] Configure a Content Security Policy.
- [ ] Review log content for unnecessary personal data.
- [ ] Review image storage and retention.
- [ ] Add a privacy policy and contact address.

## Provider integration
- [ ] Validate Bird endpoint and payload in a test workspace.
- [ ] Verify the sending domain.
- [ ] Test accepted, rejected, bounced, and delayed email cases.
- [ ] Test OpenRouter invalid key and quota errors.
- [ ] Test models that do not support chat completions.
- [ ] Verify current provider names and model identifiers.

## Reliability
- [ ] Run TypeScript checks.
- [ ] Run production build.
- [ ] Run API integration tests.
- [ ] Test database migration on a staging database.
- [ ] Verify health check monitoring.
- [ ] Verify application logs and error alerts.
- [ ] Test rollback procedure.
- [ ] Test database restore procedure.
- [ ] Verify dependency updates and vulnerability scanning.

## Operations
- [ ] Document who owns deployment credentials.
- [ ] Document how to revoke an exposed OpenRouter key.
- [ ] Document how to rotate Bird credentials.
- [ ] Define log retention and deletion schedules.
- [ ] Define user support and account recovery procedures.
- [ ] Review email broadcast consent and unsubscribe requirements.
