# Accessibility and responsive design review

## General principles

- Interactive controls should be reachable using a keyboard.
- Focus indicators should remain visible against all eight themes.
- Text and controls should maintain sufficient contrast.
- Inputs need clear labels and useful error messages.
- Modal and drawer interactions should be reviewed with keyboard-only navigation.
- Motion should remain subtle and respect reduced-motion preferences.
- Layouts should work at narrow mobile widths without horizontal page scrolling.

## Catalog

- Model cards use headings and buttons with readable names.
- Search should remain usable with a screen reader.
- Empty and loading states should be announced appropriately in a production refinement.
- Filter controls should expose their current value.
- API payload code should remain selectable and horizontally scrollable when necessary.
- The free-tier filter must be labelled independently of its checkbox.

## Authentication

- Each form field should have a visible label.
- Validation errors should be associated with the relevant field.
- Password fields should support password managers and autocomplete hints.
- OTP fields should be navigable with keyboard input.
- Do not rely on color alone to communicate an invalid value.
- Users should be able to paste an eight-character code; a production improvement is to distribute pasted characters across all eight fields.

## Modal and drawer behavior

- Focus should move into the modal when it opens.
- Escape should close the modal where appropriate.
- Focus should return to the invoking button after close.
- Background content should not remain keyboard-interactive while a modal is active.
- On mobile, drawers should fit within the viewport and expose a clear close control.
- Avoid trapping users in a dialog if an asynchronous request is pending.

## Themes

Each theme must be checked independently. A color pair that works in Night mode may not meet contrast expectations in Milk, Sky, Desert, or Luxury Gold. Do not infer accessible contrast from the color name alone.

## Responsive test widths

Suggested manual widths:
- 320 px: small Android devices.
- 360 px: common compact phones.
- 390 px: modern phones.
- 768 px: tablet portrait.
- 1024 px: tablet landscape / small laptop.
- 1280 px: desktop.
- 1440 px: wide desktop.

## Reduced motion

Add a global reduced-motion media query before public launch. Interactive transitions should not be required to understand the state of the interface.

## Localization

The current UI uses Indonesian and some English product labels. If localization is added, keep labels consistent, avoid concatenating sentence fragments, and test longer translated strings in the responsive layout.
