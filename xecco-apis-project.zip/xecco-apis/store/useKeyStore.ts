"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

type KeyState = {
  apiKey: string;
  setApiKey: (value: string) => void;
  clearKey: () => void;
};

export const useKeyStore = create<KeyState>()(
  persist(
    (set) => ({
      apiKey: "",
      setApiKey: (apiKey) => set({ apiKey }),
      clearKey: () => set({ apiKey: "" })
    }),
    {
      name: "xecco_openrouter_key",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ apiKey: state.apiKey })
    }
  )
);
