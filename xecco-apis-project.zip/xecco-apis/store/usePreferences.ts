"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export const themes = [
  "milk", "night", "sky", "deep-void", "luxury-gold", "violence", "desert", "forest"
] as const;
export type Theme = (typeof themes)[number];
export type TextStyle = "normal" | "numbers" | "emoji" | "latin" | "binary";

type PreferenceState = {
  theme: Theme;
  textStyle: TextStyle;
  setTheme: (theme: Theme) => void;
  setTextStyle: (style: TextStyle) => void;
};

export const usePreferences = create<PreferenceState>()(
  persist(
    (set) => ({
      theme: "night",
      textStyle: "normal",
      setTheme: (theme) => set({ theme }),
      setTextStyle: (textStyle) => set({ textStyle })
    }),
    { name: "xecco_preferences" }
  )
);

export function transformText(input: string, mode: TextStyle): string {
  if (mode === "numbers") {
    const keycaps: Record<string, string> = {
      "0": "0️⃣", "1": "1️⃣", "2": "2️⃣", "3": "3️⃣", "4": "4️⃣",
      "5": "5️⃣", "6": "6️⃣", "7": "7️⃣", "8": "8️⃣", "9": "9️⃣"
    };
    return input.replace(/[0-9]/g, (digit) => keycaps[digit] ?? digit);
  }
  if (mode === "emoji") return `${input} 🤖⚡`;
  if (mode === "latin") return input;
  if (mode === "binary") {
    return input.split("").map((character) =>
      character.charCodeAt(0).toString(2).padStart(8, "0")
    ).join(" ");
  }
  return input;
}
