# XeCCo APIs

A Next.js App Router application for an OpenRouter BYOK model catalog, API reference modal, browser-side playground, email OTP registration, profile settings, themes, feedback, and owner dashboard.

## Important implementation notes

- **Do not paste production secrets into source code.** Copy `.env.example` to `.env` and fill in values privately.
- The uploaded blueprint contained credential-like values. This project intentionally does not include them. Rotate any real credential that was shared in a document or chat.
- OpenRouter keys are stored in this browser's `localStorage` under the Zustand persist key `xecco_openrouter_key`. This is convenient but not equivalent to secure hardware-backed storage; anyone with access to the browser profile can potentially use the key. Clear it on shared devices.
- The seed model IDs are copied from the supplied blueprint and are not guaranteed to be currently available, correctly named, or supported by OpenRouter. Verify against the live OpenRouter model catalog before production.
- Bird email API routes and payloads depend on the Bird product/workspace configuration. Set `BIRD_EMAIL_ENDPOINT` to the verified transactional email endpoint for your account. The app intentionally fails closed when it is not configured; it does not pretend emails were sent.
- The OTP code is stored as a bcrypt hash, expires after 15 minutes, and is limited to five attempts.
- This is a deployable starter implementation, not a claim that production deployment has already been tested. Run the commands below and complete the production checklist.

## Requirements

- Node.js 20+
- PostgreSQL 14+
- A Bird account configured for transactional email (optional for local UI work; required for email verification)
- An OpenRouter API key for live playground calls

## Local setup

```bash
npm install
cp .env.example .env
# Edit DATABASE_URL and JWT_SECRET, and configure Bird credentials/endpoint.
npx prisma generate
npx prisma db push
npm run db:seed
npm run dev
```

Open http://localhost:3000.

## Environment

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | PostgreSQL connection |
| `JWT_SECRET` | HMAC session signing secret; at least 32 characters |
| `OWNER_NICKNAME` | Exact owner nickname |
| `OWNER_EMAIL` | Exact owner email |
| `BIRD_API_KEY` | Server-only Bird API credential |
| `BIRD_EMAIL_ENDPOINT` | Verified Bird transactional-email endpoint for the workspace |
| `APP_URL` | Public application URL |

## Main routes

| Route | Purpose |
|---|---|
| `/` | Home page, searchable model registry, API docs, playground, feedback |
| `/create` | Registration |
| `/verify?email=...` | 8-character OTP verification |
| `/login` | Login |
| `/profile` | Profile editor, image uploads, key vault |
| `/settings` | Eight themes, five text-style preferences |
| `/admin` | Owner-only logs, feedback, model status, OTP template, maintenance and broadcast |
| `/api/models` | Active model list |
| `/api/feedback` | Validated feedback submission |
| `/api/auth/*` | Registration, login, OTP verification, session and logout |
| `/api/admin/*` | Owner-only administrative actions |

## Security checklist before production

1. Use a unique high-entropy `JWT_SECRET` (at least 32 random bytes).
2. Use TLS/HTTPS and secure cookie settings behind your production domain.
3. Set strict database permissions and encrypted backups.
4. Add rate limiting at the reverse proxy or a shared rate-limit service for registration, login, OTP, feedback, and admin APIs.
5. Configure CSRF/origin protections for state-changing routes, plus a Content Security Policy.
6. Verify the current Bird API endpoint, authentication header, and request body against your Bird workspace docs.
7. Add a queue for broadcast emails and an explicit consent/unsubscribe policy where required.
8. Confirm that owner identity is provisioned safely. Owner status is derived from server environment identity; never accept a role from client input.
9. Verify each model ID and modality against OpenRouter. Image/video/rerank models may require separate APIs and are not chat-completion compatible.
10. Test email delivery, failed provider calls, migrations, database restore, and deployment rollback.
11. Add monitoring and alerting without logging passwords, API keys, OTPs, or message bodies unnecessarily.
12. Add abuse prevention and a privacy notice explaining localStorage key handling.

## Notes on feature behavior

- The `[ APIs ]` button is available without a key and shows an OpenRouter-compatible request example.
- The `[ TRY ]` panel calls OpenRouter directly from the browser, so usage charges/credits are governed by the user's OpenRouter account and provider terms.
- Streaming uses server-sent events from OpenRouter and parses `data:` records in the browser.
- The profile image uploader limits images to 1 MB and stores the data URL in PostgreSQL. For production, use object storage instead of large base64 database fields.
- The admin dashboard is protected by a server-side session check. Never protect administrative operations using client-side UI checks alone.

## Build and checks

```bash
npm run typecheck
npm run build
```

A successful build still depends on your local Node/npm versions, database schema generation, and the availability of provider services.
