export function getOwnerIdentity() {
  return {
    nickname: process.env.OWNER_NICKNAME ?? "",
    email: process.env.OWNER_EMAIL ?? ""
  };
}

export function checkIsOwner(nickname: string, email: string): boolean {
  const owner = getOwnerIdentity();
  return Boolean(owner.nickname && owner.email) &&
    nickname === owner.nickname &&
    email.toLowerCase() === owner.email.toLowerCase();
}
