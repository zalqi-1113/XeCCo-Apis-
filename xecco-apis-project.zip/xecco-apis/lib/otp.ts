import crypto from "node:crypto";
import bcrypt from "bcryptjs";
import { db } from "@/lib/db";

export function generateOtp() {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
  const bytes = crypto.randomBytes(8);
  return Array.from(bytes, (byte) => chars[byte % chars.length]).join("");
}

export async function storeOtp(email: string, code: string) {
  const codeHash = await bcrypt.hash(code, 10);
  const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await db.otpCode.upsert({
    where: { email },
    update: { codeHash, expiresAt, attempts: 0, createdAt: new Date() },
    create: { email, codeHash, expiresAt }
  });
}

export async function verifyOtp(email: string, code: string) {
  const record = await db.otpCode.findUnique({ where: { email } });
  if (!record) return { ok: false as const, reason: "Kode tidak ditemukan atau sudah digunakan." };
  if (record.expiresAt.getTime() < Date.now()) {
    await db.otpCode.delete({ where: { email } }).catch(() => undefined);
    return { ok: false as const, reason: "Kode kedaluwarsa. Silakan daftar ulang atau minta kode baru." };
  }
  if (record.attempts >= 5) return { ok: false as const, reason: "Batas percobaan tercapai. Minta kode baru." };
  const valid = await bcrypt.compare(code, record.codeHash);
  if (!valid) {
    await db.otpCode.update({ where: { email }, data: { attempts: { increment: 1 } } });
    return { ok: false as const, reason: "Kode verifikasi tidak valid." };
  }
  await db.$transaction([
    db.user.update({ where: { email }, data: { isVerified: true } }),
    db.otpCode.delete({ where: { email } })
  ]);
  return { ok: true as const };
}
