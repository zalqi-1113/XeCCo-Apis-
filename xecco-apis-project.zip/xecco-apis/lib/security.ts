import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "@/lib/db";
import { getOwnerIdentity } from "@/lib/owner";

const COOKIE_NAME = "xecco_session";
const secret = () => {
  const value = process.env.JWT_SECRET;
  if (!value || value.length < 32) throw new Error("JWT_SECRET must be at least 32 characters.");
  return new TextEncoder().encode(value);
};

export type SessionUser = {
  id: string;
  email: string;
  nickname: string;
  role: "OWNER" | "DEVELOPER";
};

export async function createSession(user: SessionUser) {
  const token = await new SignJWT({
    email: user.email,
    nickname: user.nickname,
    role: user.role
  })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(user.id)
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret());

  const jar = await cookies();
  jar.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7
  });
}

export async function getSession(): Promise<SessionUser | null> {
  try {
    const jar = await cookies();
    const token = jar.get(COOKIE_NAME)?.value;
    if (!token) return null;
    const { payload } = await jwtVerify(token, secret());
    if (!payload.sub || typeof payload.email !== "string" || typeof payload.nickname !== "string") return null;
    const identity = getOwnerIdentity();
    const isOwner =
      payload.nickname === identity.nickname &&
      payload.email.toLowerCase() === identity.email.toLowerCase();
    return {
      id: payload.sub,
      email: payload.email,
      nickname: payload.nickname,
      role: isOwner ? "OWNER" : "DEVELOPER"
    };
  } catch {
    return null;
  }
}

export async function requireOwner() {
  const session = await getSession();
  if (!session || session.role !== "OWNER") return null;
  return session;
}

export async function destroySession() {
  const jar = await cookies();
  jar.delete(COOKIE_NAME);
}
