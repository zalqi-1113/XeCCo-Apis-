import { z } from "zod";

export const registerSchema = z.object({
  nickname: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_-]+$/),
  email: z.string().trim().email().max(254).transform((v) => v.toLowerCase()),
  password: z.string().min(10).max(128)
});

export const loginSchema = z.object({
  nickname: z.string().trim().min(1).max(24),
  password: z.string().min(1).max(128)
});

export const verifySchema = z.object({
  email: z.string().trim().email().transform((v) => v.toLowerCase()),
  code: z.string().trim().length(8).regex(/^[A-Z0-9]{8}$/)
});

export const feedbackSchema = z.object({
  nickname: z.string().trim().min(1).max(80),
  email: z.string().trim().email().max(254),
  message: z.string().trim().min(5).max(5000)
});

export const profileSchema = z.object({
  nickname: z.string().trim().min(3).max(24).regex(/^[a-zA-Z0-9_-]+$/),
  caption: z.string().trim().max(280).optional().default("")
});
