import { NextResponse } from "next/server";

export function jsonError(message: string, status = 400) {
  return NextResponse.json({ success: false, error: message }, { status });
}

export function getClientIp(request: Request) {
  // Do not trust arbitrary forwarding headers unless your deployment proxy overwrites them.
  return request.headers.get("x-real-ip") ?? "unknown";
}

export async function readJson(request: Request) {
  try {
    return await request.json();
  } catch {
    return null;
  }
}
