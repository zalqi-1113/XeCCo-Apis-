import { db } from "@/lib/db";

export type ModelGenre =
  | "Ultra model"
  | "Thinking"
  | "Coding"
  | "Chat"
  | "Image creation"
  | "Video making"
  | "Search / Rerank";

export async function listModels() {
  return db.aIModel.findMany({
    where: { active: true },
    orderBy: [{ isFree: "desc" }, { provider: "asc" }, { name: "asc" }]
  });
}

export function isChatModel(modelId: string) {
  // Non-chat modalities may not support /chat/completions. The playground blocks them.
  return !/(image|video|rerank)/i.test(modelId);
}
