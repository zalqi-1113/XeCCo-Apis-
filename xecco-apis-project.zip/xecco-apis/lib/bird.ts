/**
 * Bird integration deliberately requires a configured endpoint because the exact
 * transactional-email API route varies by Bird workspace/product configuration.
 * Never log API keys or OTP values.
 */
export async function sendBirdEmail(input: { to: string; subject: string; body: string }) {
  const key = process.env.BIRD_API_KEY;
  const endpoint = process.env.BIRD_EMAIL_ENDPOINT;
  if (!key || !endpoint) {
    throw new Error("Bird email is not configured. Set BIRD_API_KEY and BIRD_EMAIL_ENDPOINT.");
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `AccessKey ${key}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      recipients: [{ address: input.to }],
      subject: input.subject,
      body: { text: input.body }
    }),
    cache: "no-store"
  });

  if (!response.ok) {
    const safeStatus = response.status;
    throw new Error(`Bird email request failed with status ${safeStatus}.`);
  }
}
