# Deployment checklist

## Before deploy
- [ ] Provision PostgreSQL and create a least-privilege application user.
- [ ] Add all required environment variables in the host dashboard.
- [ ] Set `APP_URL` to the HTTPS domain.
- [ ] Configure Bird transactional email and verify sender/domain.
- [ ] Verify model IDs against OpenRouter's current catalog.
- [ ] Run migrations/`prisma db push` in a controlled release step.
- [ ] Run seed data only when intended.
- [ ] Run `npm run typecheck` and `npm run build`.

## Recommended production improvements
- Use `prisma migrate deploy` with checked-in migrations instead of `db push`.
- Move base64 profile images to object storage.
- Add shared rate limiting and audit log retention rules.
- Add alerting for email provider failures and database errors.
- Add integration tests for registration, OTP expiration, login, profile changes, and owner-only routes.
- Review privacy, retention, accessibility, and applicable Indonesian legal requirements.
