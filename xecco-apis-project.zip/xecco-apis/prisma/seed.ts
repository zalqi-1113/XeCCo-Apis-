import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

const models = [
  ["nvidia/nemotron-3-ultra-550b-a55b:free", "Nemotron 3 Ultra 550B", "NVIDIA", "Ultra model", true, "128k"],
  ["nvidia/nemotron-3-super-120b-a12b:free", "Nemotron 3 Super 120B", "NVIDIA", "Ultra model", true, "128k"],
  ["nvidia/nemotron-3.5-lightning:free", "Nemotron 3.5 Lightning", "NVIDIA", "Chat", true, "64k"],
  ["apodex/apodex-1.1-mini:free", "Apodex 1.1 Mini", "Apodex", "Chat", true, "32k"],
  ["qwen/qwen3.8-27b:free", "Qwen 3.8 27B", "Qwen", "Chat", true, "128k"],
  ["poolside/laguna-s-2.1:free", "Laguna S 2.1", "Poolside", "Coding", true, "64k"],
  ["inclusionai/ling-3.1-flash", "Ling 3.1 Flash", "InclusionAI", "Chat", false, "128k"],
  ["inception/mercury-2.5", "Mercury 2.5", "Inception", "Thinking", false, "256k"],
  ["google/gemma-4-31b-it:free", "Gemma 4 31B IT", "Google", "Chat", true, "128k"],
  ["aion-labs/aion-3.5-mini", "Aion 3.5 Mini", "Aion Labs", "Chat", false, "64k"],
  ["cohere/north-mini-code:free", "North Mini Code", "Cohere", "Coding", true, "128k"],
  ["voyageai/rerank-2.5-lite", "Rerank 2.5 Lite", "VoyageAI", "Search / Rerank", false, "32k"],
  ["heygen/heygen-video-1", "HeyGen Video 1", "HeyGen", "Video making", false, "N/A"],
  ["recraft/recraft-v4.1-flash", "Recraft V4.1 Flash", "Recraft", "Image creation", false, "N/A"],
  ["black-forest-labs/flux-3-image", "FLUX 3 Image", "Black Forest Labs", "Image creation", false, "N/A"],
  ["qwen/qwen3.8-max-0902", "Qwen 3.8 Max 0902", "Qwen", "Ultra model", false, "256k"],
  ["openai/gpt-5.6-luna", "GPT-5.6 Luna", "OpenAI", "Thinking", false, "1M"],
  ["google/gemini-3.1-flash-lite", "Gemini 3.1 Flash Lite", "Google", "Chat", false, "1M"],
  ["openai/gpt-4.1-mini", "GPT-4.1 Mini", "OpenAI", "Chat", false, "1M"],
  ["anthropic/claude-3.7-sonnet", "Claude 3.7 Sonnet", "Anthropic", "Thinking", false, "200k"]
] as const;

async function main() {
  for (const [id, name, provider, genre, isFree, contextLength] of models) {
    await prisma.aIModel.upsert({
      where: { id },
      update: { name, provider, genre, isFree, contextLength },
      create: { id, name, provider, genre, isFree, contextLength }
    });
  }

  await prisma.otpTemplate.upsert({
    where: { id: "default" },
    update: {},
    create: {
      id: "default",
      template: "Halo {{email}}, kode verifikasi XeCCo APIs kamu adalah {{code}}. Kode berlaku 15 menit."
    }
  });

  await prisma.appSetting.upsert({
    where: { key: "maintenance" },
    update: {},
    create: { key: "maintenance", value: "false" }
  });
}

main()
  .then(async () => prisma.$disconnect())
  .catch(async (error) => {
    console.error(error);
    await prisma.$disconnect();
    process.exit(1);
  });
