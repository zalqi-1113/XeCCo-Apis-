"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Cpu, Settings2, UserRound, ShieldCheck } from "lucide-react";

type PublicUser = { nickname: string; role: "OWNER" | "DEVELOPER" } | null;

export function Navbar() {
  const [user, setUser] = useState<PublicUser>(null);

  useEffect(() => {
    fetch("/api/auth/me").then((res) => res.ok ? res.json() : null)
      .then((data) => setUser(data?.user ?? null)).catch(() => undefined);
  }, []);

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setUser(null);
    window.location.href = "/";
  }

  return (
    <header className="sticky top-0 z-30 border-b backdrop-blur-xl" style={{ background: "color-mix(in srgb,var(--bg) 88%,transparent)", borderColor: "var(--border)" }}>
      <div className="shell flex h-[72px] items-center justify-between gap-4">
        <Link href="/" className="flex items-center gap-3 font-bold tracking-tight">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: "var(--accent)", color: "var(--bg)" }}><Cpu size={22}/></span>
          <span>XeCCo <span style={{ color: "var(--accent)" }}>APIs</span><small className="block text-[10px] font-medium tracking-[.22em] muted">MODEL WORKSPACE</small></span>
        </Link>
        <nav className="flex items-center gap-2 text-sm">
          <Link className="btn btn-ghost hidden sm:inline-flex" href="/settings"><Settings2 size={16}/> Settings</Link>
          {user ? <>
            <Link className="btn btn-ghost" href="/profile"><UserRound size={16}/><span className="max-w-24 truncate">{user.nickname}</span></Link>
            {user.role === "OWNER" && <Link className="btn btn-ghost" href="/admin"><ShieldCheck size={16}/><span className="hidden sm:inline">Admin</span></Link>}
            <button className="btn" onClick={logout}>Keluar</button>
          </> : <>
            <Link className="btn btn-ghost" href="/login">Masuk</Link>
            <Link className="btn btn-primary" href="/create">Mulai</Link>
          </>}
        </nav>
      </div>
    </header>
  );
}
