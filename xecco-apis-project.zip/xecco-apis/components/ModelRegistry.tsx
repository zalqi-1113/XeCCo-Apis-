"use client";

import { useEffect, useMemo, useState } from "react";
import { Search, RefreshCw } from "lucide-react";
import { ModelCard, type ModelCardData } from "@/components/ModelCard";

export function ModelRegistry() {
  const [models, setModels] = useState<ModelCardData[]>([]);
  const [query, setQuery] = useState("");
  const [genre, setGenre] = useState("All");
  const [freeOnly, setFreeOnly] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true); setError("");
    try {
      const response = await fetch("/api/models", { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error ?? "Gagal memuat katalog.");
      setModels(data.models ?? []);
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Gagal memuat katalog.");
    } finally { setLoading(false); }
  }

  useEffect(() => { void load(); }, []);

  const genres = useMemo(() => ["All", ...Array.from(new Set(models.map((m) => m.genre))).sort()], [models]);
  const filtered = useMemo(() => models.filter((model) => {
    const text = `${model.name} ${model.provider} ${model.id} ${model.genre}`.toLowerCase();
    return text.includes(query.toLowerCase()) && (genre === "All" || model.genre === genre) && (!freeOnly || model.isFree);
  }), [models, query, genre, freeOnly]);

  return <>
    <div className="panel mb-5 flex flex-col gap-3 p-3 sm:flex-row">
      <label className="relative flex-1"><Search size={17} className="absolute left-3 top-1/2 -translate-y-1/2 muted"/><input className="field pl-10" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari model, provider, genre…"/></label>
      <select className="field sm:max-w-52" value={genre} onChange={(e) => setGenre(e.target.value)}>{genres.map((item) => <option key={item}>{item}</option>)}</select>
      <label className="flex items-center justify-center gap-2 px-2 text-sm"><input type="checkbox" checked={freeOnly} onChange={(e) => setFreeOnly(e.target.checked)}/> Free tier</label>
      <button className="btn" onClick={load} aria-label="Refresh models"><RefreshCw size={16}/></button>
    </div>
    {loading ? <div className="panel p-10 text-center muted">Memuat model…</div> : error ? <div className="panel p-8 text-center"><p>{error}</p><button className="btn mt-4" onClick={load}>Coba lagi</button></div> : filtered.length ? <div className="grid-models">{filtered.map((model) => <ModelCard key={model.id} model={model}/>)}</div> : <div className="panel p-10 text-center muted">Tidak ada model yang cocok dengan filter ini.</div>}
    <p className="mt-4 text-xs muted">Catatan: seed katalog mengikuti blueprint awal dan harus diverifikasi terhadap daftar model aktif OpenRouter sebelum produksi.</p>
  </>;
}
