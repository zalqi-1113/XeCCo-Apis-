"use client";

import { useEffect } from "react";
import { usePreferences } from "@/store/usePreferences";

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const theme = usePreferences((state) => state.theme);

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);

  return children;
}
