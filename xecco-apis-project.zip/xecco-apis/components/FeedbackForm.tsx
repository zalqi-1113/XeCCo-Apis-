"use client";

import { useState } from "react";

export function FeedbackForm() {
  const [nickname, setNickname] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setStatus("");
    try {
      const response = await fetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nickname, email, message })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Feedback gagal dikirim.");
      setStatus("Feedback tersimpan. Terima kasih!");
      setNickname(""); setEmail(""); setMessage("");
    } catch (error) {
      setStatus(error instanceof Error ? error.message : "Terjadi kesalahan.");
    } finally {
      setBusy(false);
    }
  }

  return <form className="panel space-y-3 p-5" onSubmit={submit}>
    <h3 className="text-lg font-bold">Kirim feedback</h3>
    <input className="field" value={nickname} onChange={(e) => setNickname(e.target.value)} placeholder="Nickname" required maxLength={80}/>
    <input className="field" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" required maxLength={254}/>
    <textarea className="field min-h-28" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Ceritakan bug, ide, atau saran…" required minLength={5} maxLength={5000}/>
    <button className="btn btn-primary w-full" disabled={busy}>{busy ? "Mengirim…" : "Kirim feedback"}</button>
    {status && <p role="status" className="text-sm muted">{status}</p>}
  </form>;
}
