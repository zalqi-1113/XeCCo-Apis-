"use client";

import { useState } from "react";
import { X, Send, KeyRound, Trash2, LoaderCircle } from "lucide-react";
import { useKeyStore } from "@/store/useKeyStore";
import type { ModelCardData } from "@/components/ModelCard";

export function PlaygroundDrawer({ model, onClose }: { model: ModelCardData; onClose: () => void }) {
  const apiKey = useKeyStore((state) => state.apiKey);
  const setApiKey = useKeyStore((state) => state.setApiKey);
  const clearKey = useKeyStore((state) => state.clearKey);
  const [showKey, setShowKey] = useState(false);
  const [systemPrompt, setSystemPrompt] = useState("You are a helpful assistant.");
  const [prompt, setPrompt] = useState("");
  const [temperature, setTemperature] = useState(0.7);
  const [maxTokens, setMaxTokens] = useState(1024);
  const [stream, setStream] = useState(false);
  const [answer, setAnswer] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function run() {
    setError("");
    setAnswer("");
    if (!apiKey.trim()) { setError("Masukkan OpenRouter API key terlebih dahulu."); return; }
    if (!prompt.trim()) { setError("Tulis prompt sebelum menjalankan model."); return; }
    setLoading(true);
    try {
      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${apiKey.trim()}`,
          "Content-Type": "application/json",
          "HTTP-Referer": window.location.origin,
          "X-Title": "XeCCo APIs"
        },
        body: JSON.stringify({
          model: model.id,
          messages: [
            ...(systemPrompt.trim() ? [{ role: "system", content: systemPrompt }] : []),
            { role: "user", content: prompt }
          ],
          temperature,
          max_tokens: maxTokens,
          stream
        })
      });
      if (!response.ok) {
        const body = await response.json().catch(() => ({}));
        throw new Error(body?.error?.message ?? `OpenRouter returned HTTP ${response.status}`);
      }
      if (stream && response.body) {
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = "";
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            if (!line.startsWith("data: ")) continue;
            const data = line.slice(6).trim();
            if (data === "[DONE]") continue;
            try {
              const json = JSON.parse(data);
              const token = json.choices?.[0]?.delta?.content;
              if (typeof token === "string") setAnswer((old) => old + token);
            } catch { /* Ignore incomplete SSE events. */ }
          }
        }
      } else {
        const body = await response.json();
        const content = body.choices?.[0]?.message?.content;
        setAnswer(typeof content === "string" ? content : JSON.stringify(content ?? body, null, 2));
      }
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "Permintaan gagal.");
    } finally {
      setLoading(false);
    }
  }

  return <div className="fixed inset-0 z-50 flex justify-end bg-black/70" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
    <section className="h-full w-full max-w-2xl overflow-y-auto p-4 sm:p-7" style={{ background: "var(--bg)", borderLeft: "1px solid var(--border)" }}>
      <div className="flex items-start justify-between gap-3">
        <div><p className="text-xs muted">LIVE PLAYGROUND</p><h2 className="mt-1 text-xl font-bold">{model.name}</h2><p className="mt-1 text-sm muted">Requests are sent directly from your browser to OpenRouter.</p></div>
        <button className="btn" onClick={onClose}><X size={18}/></button>
      </div>

      <div className="panel mt-5 p-4">
        <label className="mb-2 flex items-center gap-2 text-sm font-semibold"><KeyRound size={16}/> OpenRouter API key</label>
        <div className="flex gap-2">
          <input className="field min-w-0" value={apiKey} onChange={(e) => setApiKey(e.target.value)} type={showKey ? "text" : "password"} placeholder="sk-or-v1-..." autoComplete="off"/>
          <button className="btn" onClick={() => setShowKey((v) => !v)}>{showKey ? "Hide" : "Show"}</button>
        </div>
        <div className="mt-2 flex flex-wrap gap-2"><button className="btn" onClick={clearKey}><Trash2 size={14}/> Clear browser key</button><a className="btn" href="https://openrouter.ai/keys" target="_blank" rel="noreferrer">Manage keys ↗</a></div>
        <p className="mt-2 text-xs muted">Stored in this browser’s localStorage. Anyone with access to this browser profile may be able to use it. Clear the key on shared devices.</p>
      </div>

      <div className="mt-5 space-y-4">
        <div><label className="mb-2 block text-sm font-semibold">System prompt</label><textarea className="field min-h-20" value={systemPrompt} onChange={(e) => setSystemPrompt(e.target.value)}/></div>
        <div><label className="mb-2 block text-sm font-semibold">Your prompt</label><textarea className="field min-h-28" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Tulis pertanyaan atau instruksi…"/></div>
        <div className="grid grid-cols-2 gap-4">
          <label className="text-sm">Temperature <strong className="float-right">{temperature.toFixed(1)}</strong><input className="mt-3 w-full" type="range" min="0" max="2" step="0.1" value={temperature} onChange={(e) => setTemperature(Number(e.target.value))}/></label>
          <label className="text-sm">Max tokens <strong className="float-right">{maxTokens}</strong><input className="mt-3 w-full" type="range" min="1" max="8192" step="1" value={maxTokens} onChange={(e) => setMaxTokens(Number(e.target.value))}/></label>
        </div>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={stream} onChange={(e) => setStream(e.target.checked)}/> Stream response (live tokens)</label>
        <button className="btn btn-primary w-full" onClick={run} disabled={loading}>{loading ? <LoaderCircle className="animate-spin" size={17}/> : <Send size={17}/>} {loading ? "Menjalankan model…" : "Jalankan model"}</button>
        {error && <div role="alert" className="rounded-xl border border-red-500/50 bg-red-950/30 p-3 text-sm text-red-300">{error}</div>}
        <div className="panel min-h-36 p-4"><div className="mb-3 flex items-center justify-between"><h3 className="font-semibold">Response</h3>{answer && <button className="btn" onClick={() => navigator.clipboard.writeText(answer)}>Salin</button>}</div>{answer ? <pre className="whitespace-pre-wrap break-words text-sm leading-relaxed">{answer}</pre> : <p className="text-sm muted">Hasil model akan muncul di sini.</p>}</div>
      </div>
    </section>
  </div>;
}
