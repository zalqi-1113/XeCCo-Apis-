"use client";

import { useState } from "react";
import { Braces, Play, Copy, Check, X, Sparkles } from "lucide-react";
import { PlaygroundDrawer } from "@/components/PlaygroundDrawer";

export type ModelCardData = {
  id: string; name: string; provider: string; genre: string;
  isFree: boolean; contextLength: string;
};

export function ModelCard({ model }: { model: ModelCardData }) {
  const [docsOpen, setDocsOpen] = useState(false);
  const [playOpen, setPlayOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const payload = JSON.stringify({
    model: model.id,
    messages: [
      { role: "system", content: "You are a helpful assistant." },
      { role: "user", content: "Your prompt here" }
    ],
    temperature: 0.7,
    max_tokens: 1024
  }, null, 2);

  async function copyPayload() {
    await navigator.clipboard.writeText(payload);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <>
      <article className="panel flex min-h-[240px] flex-col p-5 transition hover:-translate-y-0.5" style={{ transition: "transform .16s,border-color .16s" }}>
        <div className="flex items-start justify-between gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-xl" style={{ background: "var(--panel-2)", color: "var(--accent)" }}><Sparkles size={21}/></div>
          <span className="pill">{model.isFree ? "Free tier" : "Pay per use"}</span>
        </div>
        <div className="mt-4">
          <h3 className="text-base font-bold leading-snug">{model.name}</h3>
          <p className="mt-1 text-sm muted">{model.provider} · {model.genre}</p>
        </div>
        <div className="mt-4 flex items-center justify-between text-xs muted">
          <span className="pill">{model.contextLength} context</span>
          <span className="truncate">{model.id}</span>
        </div>
        <div className="mt-auto grid grid-cols-2 gap-2 pt-5">
          <button className="btn" onClick={() => setDocsOpen(true)}><Braces size={16}/> APIs</button>
          <button className="btn btn-primary" onClick={() => setPlayOpen(true)}><Play size={16}/> TRY</button>
        </div>
      </article>

      {docsOpen && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4" onMouseDown={(e) => { if (e.target === e.currentTarget) setDocsOpen(false); }}>
        <section className="panel w-full max-w-2xl p-5 sm:p-7">
          <div className="flex items-center justify-between gap-3">
            <div><p className="text-xs muted">API REFERENCE</p><h2 className="mt-1 text-xl font-bold">{model.name}</h2></div>
            <button className="btn" onClick={() => setDocsOpen(false)} aria-label="Close"><X size={18}/></button>
          </div>
          <p className="mt-4 text-sm muted">OpenRouter-compatible chat completion endpoint. Check the provider’s current model documentation for modality and parameter support.</p>
          <div className="panel-soft mt-4 p-3 text-sm"><span className="pill">POST</span> <code className="ml-2 break-all">https://openrouter.ai/api/v1/chat/completions</code></div>
          <div className="mt-4 flex items-center justify-between"><h3 className="font-semibold">JSON request payload</h3><button className="btn" onClick={copyPayload}>{copied ? <Check size={15}/> : <Copy size={15}/>} {copied ? "Copied" : "Copy"}</button></div>
          <pre className="mt-2 max-h-64 overflow-auto rounded-xl p-4 text-xs leading-relaxed" style={{ background: "var(--bg)", border: "1px solid var(--border)" }}><code>{payload}</code></pre>
          <p className="mt-3 text-xs muted">Keep your API key private. The key is read from this browser and is not sent to XeCCo’s server.</p>
        </section>
      </div>}

      {playOpen && <PlaygroundDrawer model={model} onClose={() => setPlayOpen(false)}/>}
    </>
  );
}
